document.addEventListener('scroll', function(){
    checkHeaderY()
})